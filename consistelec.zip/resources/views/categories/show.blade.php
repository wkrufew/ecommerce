<x-app-layout>
    <div class="contenedor pt-4 pb-8">
        @livewire('category-filter', ['category' => $category])
    </div>
</x-app-layout>