<div class="w-full md:w-72 h-full rounded-full relative">
    <div class="">
        <form action="{{ route('search') }}" autocomplete="off">
            <input name="name" wire:model..debounce.500ms="search" type="text" placeholder="Busque un producto por su nombre ..." class="placeholder:text-gray-400 w-full text-sm md:text-xs bg-white border border-[#60A3BD] rounded-full focus:outline-none  focus:border-[#60A3BD]">
            <div class="absolute inset-y-0 right-0 flex items-center pointer-events-auto cursor-pointer">
                <svg class="h-7 w-7 p-1.5 mr-0.5 flex justify-center items-center text-[#60A3BD] bg-gray-200 rounded-full" viewBox="0 0 24 24" fill="none">
                    <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round"stroke-linejoin="round"></path>
                </svg>
            </div>
        </form>
    </div>
    <div class="absolute w-full mt-1 hidden z-50" :class="{ 'hidden' : !$wire.open }" x-on:click.away="$wire.open = false">
        <div class="bg-white rounded-lg shadow-lg">
            <div class="px-4 py-3 space-y-1">
                @forelse ($products as $product)
                    <a href="{{ route('products.show', $product) }}" class="flex hover:bg-gray-200 rounded-full">
                        <img loading="lazy" class="w-12 h-12 object-cover rounded-full" src="{{ Storage::url($product->featuredImage()) }}" alt="">
                        <div class="ml-4 text-xs flex flex-col justify-center">
                            <p class="font-semibold leading-5">{{$product->name}}</p>
                            <p> {{$product->subcategory->category->name}}</p>
                        </div>
                    </a>
                @empty
                    <p class="h-6 rounded-lg w-full text-[#3E3E66] text-sm">
                        Sin coincidencias
                    </p>
                @endforelse
            </div>
        </div>
    </div>
</div>
{{-- <div x-data="{ expanded: false, inputWidth: '0' }" x-on:click.away="expanded = false" class="relative">
    <div class=""  x-on:click="expanded = true">
        <form action="{{ route('search') }}" autocomplete="off">
            <input name="name" wire:model="search" x-bind:placeholder="expanded ? 'Buscar un producto...' : ''" x-bind:class="{ 'w-72': expanded, 'w-0': !expanded }" type="text" class="py-1 pr-0 pl-8 block w-0 bg-white border border-indigo-300 rounded-full focus:outline-none focus:border-indigo-500 transition-width duration-300">
        <span class="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-auto cursor-pointer">
            <svg x-on:click="expanded = false" class="h-5 w-5 text-indigo-400" viewBox="0 0 24 24" fill="none">
                <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round"stroke-linejoin="round"></path>
            </svg>
        </span>
        </form>
    </div>

    <div class="absolute w-full mt-1 hidden" :class="{ 'hidden' : !$wire.open }" @click.away="$wire.open = false">
        <div class="bg-white rounded-lg shadow-lg">
            <div class="px-4  py-3 space-y-1" x-on:click.away="expanded = false">
                @forelse ($products as $product)
                    <a href="{{ route('products.show', $product) }}" class="flex hover:bg-gray-200 rounded-md">
                        <img class="w-12 h-12 object-cover rounded-full" src="{{ Storage::url($product->featuredImage()) }}" alt="">
                        <div class="ml-4 text-sm">
                            <p class="font-semibold leading-5">{{$product->name}}</p>
                            <p> {{$product->subcategory->category->name}}</p>
                        </div>
                    </a>
                @empty
                    <p class="text-lg leading-5">
                        No existe ningún registro con los parametros especificados
                    </p>
                @endforelse
            </div>
        </div>
    </div>
</div> --}}