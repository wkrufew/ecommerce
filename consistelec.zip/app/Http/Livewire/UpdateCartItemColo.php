<?php

namespace App\Http\Livewire;

use Livewire\Component;

class UpdateCartItemColo extends Component
{
    public function render()
    {
        return view('livewire.update-cart-item-colo');
    }
}
